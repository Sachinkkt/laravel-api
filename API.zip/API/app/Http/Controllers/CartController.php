<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
class CartController extends Controller
{
    //

    public function cart() {
     
 
        $cart = Http::post('https://fakedata.nanocorp.io/api/payment/create', [
            'order_id' => 1,
            'customer_email' => 'test@gmail.com',
            'amount' => 11.99,
        ]);
        
        
        
        $response = Http::post('https://fakedata.nanocorp.io/api/payment/confirm', [
            'payment_intend' => $cart,
         
        ]);
    }
}
